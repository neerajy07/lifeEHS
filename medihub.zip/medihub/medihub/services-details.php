<?php include('./inclue.php/header.php') ?>
<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

   

    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area shadow dark bg-fixed text-light" style="background-image: url(assets/img/banner/2.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1>Services Single</h1>
                </div>
                <div class="col-md-6 text-right">
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Services</a></li>
                        <li class="active">Single</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Services Details
    ============================================= -->
    <div class="services-details-area default-padding">
        <div class="container">
            <div class="row">
                <!-- Services Content -->
                <div class="col-md-8 content">
                    <div class="thumb">
                        <img src="assets/img/departments/4.jpg" alt="Thumb">
                    </div>
                    <div class="info">
                        <h2>Dental Care and Surgery</h2>
                        <p>
                            Age forming covered you entered the examine. Blessing scarcely confined her contempt wondered shy. Dashwoods contented sportsmen at up no convinced cordially affection. Am so continued resembled frankness disposing engrossed dashwoods. Earnest greater on no observe fortune norland. Hunted mrs ham wishes stairs. Continued he as so breakfast shameless. All men drew its post knew. Of talking of calling however civilly wishing resolve. 
                        </p>
                        <p>
                            Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Procuring continued suspicion its ten. Pursuit brother are had fifteen distant has. Early had add equal china quiet visit. Appear an manner as no limits either praise in. In in written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. 
                        </p>
                        <h4>Services features</h4>
                        <ul>
                            <li>Stretchers and Stretcher Accessories</li>
                            <li>International Drug Database</li>
                            <li>Cushions and Mattresses</li>
                            <li>Cholesterol and lipid tests</li>
                            <li>Critical Care Medicine Specialists</li>
                            <li>Emergency Assistance</li>
                        </ul>
                        <a class="btn btn-theme effect btn-md" href="#">Meet With Doctor</a>
                    </div>
                </div>
                <!-- End Services Content -->

                <!-- Widget Items -->
                <div class="col-md-4 sidebar">
                    <!-- Single Widget -->
                    <div class="widget appoinment">
                        <div class="title">
                            <h4>Make an Appointment</h4>
                        </div>
                        <div class="appoinment-box">
                            <form action="#">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input class="form-control" id="name" name="name" placeholder="Name" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <select>
                                                <option value="1">Male</option>
                                                <option value="2">Female</option>
                                                <option value="3">Child</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <select>
                                                <option value="1">Department</option>
                                                <option value="2">Medecine</option>
                                                <option value="4">Dental Care</option>
                                                <option value="5">Traumatology</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group comments">
                                            <textarea class="form-control" id="comments" name="comments" placeholder="Your Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" name="submit" id="submit">
                                            Submit Query <i class="fa fa-paper-plane"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End Single Widget -->

                    <!-- Single Widget -->
                    <div class="widget doctor text-center">
                        <div class="title">
                            <h4>Expert Doctor</h4>
                        </div>
                        <div class="thumb">
                            <img src="assets/img/doctors/5.jpg" alt="Thumb">
                            <div class="overlay">
                                <h4>Jessica Jones</h4>
                                <h5>Cargiologist</h5>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Widget -->

                    <!-- Single Widget -->
                    <div class="widget link">
                        <div class="title">
                            <h4>Our Departments</h4>
                        </div>
                        <ul>
                            <li>
                                <a href="#"><i class="fas fa-angle-right"></i> Medecine and Health</a>
                            </li>
                            <li>
                                <a href="#"><i class="fas fa-angle-right"></i> Dental Care and Surgery</a>
                            </li>
                            <li>
                                <a href="#"><i class="fas fa-angle-right"></i> Eye Treatment</a>
                            </li>
                            <li>
                                <a href="#"><i class="fas fa-angle-right"></i> Children Chare</a>
                            </li>
                            <li>
                                <a href="#"><i class="fas fa-angle-right"></i> Nuclear magnetic</a>
                            </li>
                        </ul>
                    </div>
                    <!-- End Single Widget -->

                    <!-- Single Widget -->
                    <div class="widget opening-hours">
                        <div class="title">
                            <h4>Opening Hours</h4>
                        </div>
                        <ul>
                            <li> <span> Mon - Tues :  </span>
                              <div class="pull-right"> 6.00 am - 10.00 pm </div>
                            </li>
                            <li> <span> Wednes - Thurs :</span>
                              <div class="pull-right"> 8.00 am - 6.00 pm </div>
                            </li>
                            <li> <span> Sun : </span>
                              <div class="pull-right closed"> Closed </div>
                            </li>
                        </ul>
                    </div>
                    <!-- End Single Widget -->
                </div>
                <!-- End Widget Items -->

            </div>
        </div>
    </div>
    <!-- End End Services -->
     <!-- HOMEPAGECOMPONENT -->
     <div class="doctor-tips-area default-padding bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Health <span>Tips</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="health-tips-items tips-carousel owl-carousel owl-theme">
                    <!-- Single Item -->
                    <div class="single-item">
                        <div class="col-md-5">
                            <div class="thumb">
                                <img src="assets/img/doctors/1.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="info">
                                <div class="doctor">
                                    <h4>Dr. Jessica Ronal</h4>
                                    <h5>MPH, Medicine, Surgery</h5>
                                </div>
                                <h3>How to live a healthy lifestyle?</h3>
                                <p>
                                    Frequently partiality possession resolution at or appearance unaffected he me. Engaged its was evident pleased husband. Ye goodness felicity do disposal dwelling no. First am plate jokes to began of cause an scale. Subjects he prospect elegance followed no overcame possible it on. 
                                </p>
                                <h4>Follow the instructions</h4>
                                <ul>
                                    <li>Dont just worry about the things you cannot help.</li>
                                    <li>Eat Healthy, work better, do gardening.</li>
                                    <li>Some relationships can kill you. Avoid them at the most.</li>
                                    <li>Focus on the good things that you like</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="single-item">
                        <div class="col-md-5">
                            <div class="thumb">
                                <img src="assets/img/doctors/5.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="info">
                                <div class="doctor">
                                    <h4>Dr. Jessica Ronal</h4>
                                    <h5>MPH, Medicine, Surgery</h5>
                                </div>
                                <h3>How to live a healthy lifestyle?</h3>
                                <p>
                                    Frequently partiality possession resolution at or appearance unaffected he me. Engaged its was evident pleased husband. Ye goodness felicity do disposal dwelling no. First am plate jokes to began of cause an scale. Subjects he prospect elegance followed no overcame possible it on. 
                                </p>
                                <h4>Follow the instructions</h4>
                                <ul>
                                    <li>Dont just worry about the things you cannot help.</li>
                                    <li>Eat Healthy, work better, do gardening.</li>
                                    <li>Some relationships can kill you. Avoid them at the most.</li>
                                    <li>Focus on the good things that you like</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="single-item">
                        <div class="col-md-5">
                            <div class="thumb">
                                <img src="assets/img/doctors/6.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="info">
                                <div class="doctor">
                                    <h4>Dr. Jessica Ronal</h4>
                                    <h5>MPH, Medicine, Surgery</h5>
                                </div>
                                <h3>How to live a healthy lifestyle?</h3>
                                <p>
                                    Frequently partiality possession resolution at or appearance unaffected he me. Engaged its was evident pleased husband. Ye goodness felicity do disposal dwelling no. First am plate jokes to began of cause an scale. Subjects he prospect elegance followed no overcame possible it on. 
                                </p>
                                <h4>Follow the instructions</h4>
                                <ul>
                                    <li>Dont just worry about the things you cannot help.</li>
                                    <li>Eat Healthy, work better, do gardening.</li>
                                    <li>Some relationships can kill you. Avoid them at the most.</li>
                                    <li>Focus on the good things that you like</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>


    <!-- Start Footer 
    ============================================= -->
    <?php include('./inclue.php/footer.php') ?>

