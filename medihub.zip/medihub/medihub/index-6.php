<?php include('./inclue.php/header.php') ?>
<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

   

    <!-- Start Banner 
    ============================================= -->
    <div class="banner-area">
        <div id="bootcarousel" class="carousel text-center inc-top-heading slide carousel-fade animate_text" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner text-light carousel-zoom">
                <div class="item active">
                    <div class="slider-thumb bg-cover" style="background-image: url(assets/img/banner/11.jpg);"></div>
                    <div class="box-table shadow dark">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-10 col-md-offset-1">
                                        <div class="content">
                                            <h1 data-animation="animated slideInRight">Best care for your <span> Good health</span></h1>
                                            <p data-animation="animated slideInUp">
                                                The ourselves suffering the sincerity. Inhabit her manners adapted age certain.<br> Debating offended at branched striking be subjects.
                                            </p>
                                            <a data-animation="animated slideInUp" class="btn btn-light border btn-md" href="#">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="slider-thumb bg-cover" style="background-image: url(assets/img/banner/12.jpg);"></div>
                    <div class="box-table shadow dark">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-10 col-md-offset-1">
                                        <div class="content">
                                            <h1 data-animation="animated slideInRight">Special for <span>expert</span> heart specialist</h1>
                                            <p data-animation="animated slideInUp">
                                                The ourselves suffering the sincerity. Inhabit her manners adapted age certain.<br> Debating offended at branched striking be subjects.
                                            </p>
                                            <a data-animation="animated slideInUp" class="btn btn-light border btn-md" href="#">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="slider-thumb bg-cover" style="background-image: url(assets/img/banner/13.jpg);"></div>
                    <div class="box-table shadow dark">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-10 col-md-offset-1">
                                        <div class="content">
                                            <h1 data-animation="animated slideInRight">24 hours <span>emergency</span> services</h1>
                                            <p data-animation="animated slideInUp">
                                                The ourselves suffering the sincerity. Inhabit her manners adapted age certain.<br> Debating offended at branched striking be subjects.
                                            </p>
                                            <a data-animation="animated slideInUp" class="btn btn-light border btn-md" href="#">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Wrapper for slides -->

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#bootcarousel" data-slide="prev">
                <i class="fa fa-angle-left"></i>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#bootcarousel" data-slide="next">
                <i class="fa fa-angle-right"></i>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <!-- End Banner -->

    <!-- Start About
    ============================================= -->
    <div class="about-area default-padding">
        <div class="container">
            <div class="row">
                <div class="about-items">
                    <div class="col-md-6 info">
                        <h4>Has been working since 2000</h4>
                        <h2>A Great Place to Work. A Great Place to Receive Care. Leading Medicine.</h2>
                        <p>
                            However venture pursuit he am mr cordial. Forming musical am hearing studied be luckily. Ourselves for determine attending how led gentleman sincerity. Valley afford uneasy joy she thrown though bed set. In me forming general prudent on country carried. Behaved an or suppose justice. Seemed whence how son rather easily and change missed.
                        </p>
                        <div class="bottom">
                            <div class="video">
                                <a href="https://www.youtube.com/watch?v=5vY-D42NFP4" class="popup-youtube relative theme video-play-button item-center">
                                    <i class="fa fa-play"></i>
                                </a>
                            </div>
                            <div class="content">
                                <h4>Let’s see our intro video</h4>
                                <p>
                                    If your smile is not becoming to you, then you should be coming to me!
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 emergency-services">
                        <h2>Our 24/7 Emergency Services</h2>
                        <div class="em-services-items">
                            <div class="table-responsive">          
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Day</th>
                                            <th>Time</th>
                                            <th>Service</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Sunday</td>
                                            <td>8:00 - 24:00</td>
                                            <td>Medecine and Health</td>
                                        </tr>
                                        <tr>
                                            <td>Monday</td>
                                            <td>10:00 - 18:00</td>
                                            <td>Dental Care and Surgery</td>
                                        </tr>
                                        <tr>
                                            <td>Tuesday</td>
                                            <td>6:00 - 24:00</td>
                                            <td>Eye Treatment</td>
                                        </tr>
                                        <tr>
                                            <td>Wednesday</td>
                                            <td>12:00 - 20:00</td>
                                            <td>Children Chare</td>
                                        </tr>
                                        <tr>
                                            <td>Thursday</td>
                                            <td>11:20 - 20:45</td>
                                            <td>Traumatology</td>
                                        </tr>
                                        <tr>
                                            <td>Friday</td>
                                            <td>0:00 - 0:00</td>
                                            <td>Day Off</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About -->

    <!-- Start Services 
    ============================================= -->
    <div class="services-area inc-icon bg-gray carousel-shadow default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Centres of <span>Excellence</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="services-items text-center services-carousel owl-carousel owl-theme">
                        <!-- Single Item -->
                        <div class="item">
                            <div class="info">
                                <h4>
                                    <a href="#">Body Surgery</a>
                                </h4>
                                <div class="overlay">
                                    <i class="flaticon-medical"></i>
                                </div>
                                <p>
                                    Attachment astonished to on appearance imprudence so collecting in excellence. Tiled way blind lived whose new. The for fully had she there leave merit enjoy forth.
                                </p>
                                <a class="btn btn-theme border circle btn-md" href="#">Read More</a>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="info">
                                <h4>
                                    <a href="#">Dental Care</a>
                                </h4>
                                <div class="overlay">
                                    <i class="flaticon-anesthesia"></i>
                                </div>
                                <p>
                                    Attachment astonished to on appearance imprudence so collecting in excellence. Tiled way blind lived whose new. The for fully had she there leave merit enjoy forth.
                                </p>
                                <a class="btn btn-theme border circle btn-md" href="#">Read More</a>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="info">
                                <h4>
                                    <a href="#">Eye Care</a>
                                </h4>
                                <div class="overlay">
                                    <i class="flaticon-anatomy"></i>
                                </div>
                                <p>
                                    Attachment astonished to on appearance imprudence so collecting in excellence. Tiled way blind lived whose new. The for fully had she there leave merit enjoy forth.
                                </p>
                                <a class="btn btn-theme border circle btn-md" href="#">Read More</a>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="info">
                                <h4>
                                    <a href="#">Blood Cancer</a>
                                </h4>
                                <div class="overlay">
                                    <i class="flaticon-lung-cancer"></i>
                                </div>
                                <p>
                                    Attachment astonished to on appearance imprudence so collecting in excellence. Tiled way blind lived whose new. The for fully had she there leave merit enjoy forth.
                                </p>
                                <a class="btn btn-theme border circle btn-md" href="#">Read More</a>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="info">
                                <h4>
                                    <a href="#">Neurology Sargery</a>
                                </h4>
                                <div class="overlay">
                                    <i class="flaticon-thinking"></i>
                                </div>
                                <p>
                                    Attachment astonished to on appearance imprudence so collecting in excellence. Tiled way blind lived whose new. The for fully had she there leave merit enjoy forth.
                                </p>
                                <a class="btn btn-theme border circle btn-md" href="#">Read More</a>
                            </div>
                        </div>
                        <!-- End Single Item -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Services -->

    <!-- Start Departments
    ============================================= -->
    <div class="department-tabs default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-3 tab-navs">
                    <div class="heading">
                        <h4>Our Departments</h4>
                    </div>
                    <!-- Tab Nav -->
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a data-toggle="tab" href="#tab1" aria-expanded="true">
                                 Medecine and Health
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#tab2" aria-expanded="false">
                                Dental Care and Surgery
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#tab3" aria-expanded="false">
                                 Eye Treatment
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#tab4" aria-expanded="false">
                                Children Chare
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#tab5" aria-expanded="false">
                                Nuclear magnetic
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#tab6" aria-expanded="false">
                                Traumatology
                            </a>
                        </li>
                    </ul>
                    <!-- End Tab Nav -->
                </div>
                <div class="col-md-9 tab-contents">
                    <div class="row">
                        <!-- Start Tab Content -->
                        <div class="tab-content tab-content-info">
                            <!-- Single Item -->
                            <div id="tab1" class="tab-pane fade active in">

                                <!-- Start Department Info -->
                                <div class="col-md-6">
                                    <div class="info title">
                                        <div class="thumb">
                                            <img src="assets/img/departments/1.jpg" alt="Thumb">
                                        </div>
                                        <h3>Medecine and Health</h3>
                                        <p>
                                            Calling nothing end fertile for venture way boy. Esteem spirit temper too say adieus who direct esteem. It esteems luckily mr or picture placing drawing no. Apartments frequently or motionless on reasonable projecting expression. Way mrs end gave tall walk fact bed. 
                                        </p>
                                        <p>
                                            Placing assured be if removed it besides on. Far shed each high read are men over day.
                                        </p>
                                    </div>
                                </div>
                                <!-- End Department Info -->

                                <!-- Start Opening Hours -->
                                <div class="col-md-6 opening-hours">
                                    <div class="opening-info">
                                        <h4>Opening Hours</h4>
                                        <ul>
                                            <li>Sunday <div class="pull-right"> 6.00 am - 10.00 pm </div></li>
                                            <li>Monday <div class="pull-right"> 8.00 am - 4.00 pm </div></li>
                                            <li>Tuesday <div class="pull-right"> 9.00 am - 6.00 pm </div></li>
                                            <li>Wednesday <div class="pull-right"> 10.00 am - 7.00 pm </div></li>
                                            <li>Thursday <div class="pull-right"> 11.00 am - 9.00 pm </div></li>
                                            <li>Friday <div class="pull-right"> 12.00 am - 12.00 pm </div></li>
                                            <li>Saturday <div class="pull-right closed"> Closed </div></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Opening Hours -->

                            </div>
                            <!-- End Single Item -->

                            <!-- Single Item -->
                            <div id="tab2" class="tab-pane fade">
                                <!-- Start Department Info -->
                                <div class="col-md-6">
                                    <div class="info title">
                                        <div class="thumb">
                                            <img src="assets/img/departments/2.jpg" alt="Thumb">
                                        </div>
                                        <h3>Dental Care and Surgery</h3>
                                        <p>
                                            Calling nothing end fertile for venture way boy. Esteem spirit temper too say adieus who direct esteem. It esteems luckily mr or picture placing drawing no. Apartments frequently or motionless on reasonable projecting expression. Way mrs end gave tall walk fact bed. 
                                        </p>
                                        <p>
                                            Placing assured be if removed it besides on. Far shed each high read are men over day.
                                        </p>
                                    </div>
                                </div>
                                <!-- End Department Info -->

                                <!-- Start Opening Hours -->
                                <div class="col-md-6 opening-hours">
                                    <div class="opening-info">
                                        <h4>Opening Hours</h4>
                                        <ul>
                                            <li>Sunday <div class="pull-right"> 6.00 am - 10.00 pm </div></li>
                                            <li>Monday <div class="pull-right"> 8.00 am - 4.00 pm </div></li>
                                            <li>Tuesday <div class="pull-right"> 9.00 am - 6.00 pm </div></li>
                                            <li>Wednesday <div class="pull-right"> 10.00 am - 7.00 pm </div></li>
                                            <li>Thursday <div class="pull-right"> 11.00 am - 9.00 pm </div></li>
                                            <li>Friday <div class="pull-right"> 12.00 am - 12.00 pm </div></li>
                                            <li>Saturday <div class="pull-right closed"> Closed </div></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Opening Hours -->
                            </div>
                            <!-- End Single Item -->

                            <!-- Single Item -->
                            <div id="tab3" class="tab-pane fade">
                                <!-- Start Department Info -->
                                <div class="col-md-6">
                                    <div class="info title">
                                        <div class="thumb">
                                            <img src="assets/img/departments/3.jpg" alt="Thumb">
                                        </div>
                                        <h3>Eye Treatment</h3>
                                        <p>
                                            Calling nothing end fertile for venture way boy. Esteem spirit temper too say adieus who direct esteem. It esteems luckily mr or picture placing drawing no. Apartments frequently or motionless on reasonable projecting expression. Way mrs end gave tall walk fact bed. 
                                        </p>
                                        <p>
                                            Placing assured be if removed it besides on. Far shed each high read are men over day.
                                        </p>
                                    </div>
                                </div>
                                <!-- End Department Info -->

                                <!-- Start Opening Hours -->
                                <div class="col-md-6 opening-hours">
                                    <div class="opening-info">
                                        <h4>Opening Hours</h4>
                                        <ul>
                                            <li>Sunday <div class="pull-right"> 6.00 am - 10.00 pm </div></li>
                                            <li>Monday <div class="pull-right"> 8.00 am - 4.00 pm </div></li>
                                            <li>Tuesday <div class="pull-right"> 9.00 am - 6.00 pm </div></li>
                                            <li>Wednesday <div class="pull-right"> 10.00 am - 7.00 pm </div></li>
                                            <li>Thursday <div class="pull-right"> 11.00 am - 9.00 pm </div></li>
                                            <li>Friday <div class="pull-right"> 12.00 am - 12.00 pm </div></li>
                                            <li>Saturday <div class="pull-right closed"> Closed </div></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Opening Hours -->
                            </div>
                            <!-- End Single Item -->

                            <!-- Single Item -->
                            <div id="tab4" class="tab-pane fade">
                                <!-- Start Department Info -->
                                <div class="col-md-6">
                                    <div class="info title">
                                        <div class="thumb">
                                            <img src="assets/img/departments/4.jpg" alt="Thumb">
                                        </div>
                                        <h3>Children Chare</h3>
                                        <p>
                                            Calling nothing end fertile for venture way boy. Esteem spirit temper too say adieus who direct esteem. It esteems luckily mr or picture placing drawing no. Apartments frequently or motionless on reasonable projecting expression. Way mrs end gave tall walk fact bed. 
                                        </p>
                                        <p>
                                            Placing assured be if removed it besides on. Far shed each high read are men over day.
                                        </p>
                                    </div>
                                </div>
                                <!-- End Department Info -->

                                <!-- Start Opening Hours -->
                                <div class="col-md-6 opening-hours">
                                    <div class="opening-info">
                                        <h4>Opening Hours</h4>
                                        <ul>
                                            <li>Sunday <div class="pull-right"> 6.00 am - 10.00 pm </div></li>
                                            <li>Monday <div class="pull-right"> 8.00 am - 4.00 pm </div></li>
                                            <li>Tuesday <div class="pull-right"> 9.00 am - 6.00 pm </div></li>
                                            <li>Wednesday <div class="pull-right"> 10.00 am - 7.00 pm </div></li>
                                            <li>Thursday <div class="pull-right"> 11.00 am - 9.00 pm </div></li>
                                            <li>Friday <div class="pull-right"> 12.00 am - 12.00 pm </div></li>
                                            <li>Saturday <div class="pull-right closed"> Closed </div></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Opening Hours -->
                            </div>
                            <!-- End Single Item -->

                            <!-- Single Item -->
                            <div id="tab5" class="tab-pane fade">
                                <!-- Start Department Info -->
                                <div class="col-md-6">
                                    <div class="info title">
                                        <div class="thumb">
                                            <img src="assets/img/departments/5.jpg" alt="Thumb">
                                        </div>
                                        <h3>Nuclear magnetic</h3>
                                        <p>
                                            Calling nothing end fertile for venture way boy. Esteem spirit temper too say adieus who direct esteem. It esteems luckily mr or picture placing drawing no. Apartments frequently or motionless on reasonable projecting expression. Way mrs end gave tall walk fact bed. 
                                        </p>
                                        <p>
                                            Placing assured be if removed it besides on. Far shed each high read are men over day.
                                        </p>
                                    </div>
                                </div>
                                <!-- End Department Info -->

                                <!-- Start Opening Hours -->
                                <div class="col-md-6 opening-hours">
                                    <div class="opening-info">
                                        <h4>Opening Hours</h4>
                                        <ul>
                                            <li>Sunday <div class="pull-right"> 6.00 am - 10.00 pm </div></li>
                                            <li>Monday <div class="pull-right"> 8.00 am - 4.00 pm </div></li>
                                            <li>Tuesday <div class="pull-right"> 9.00 am - 6.00 pm </div></li>
                                            <li>Wednesday <div class="pull-right"> 10.00 am - 7.00 pm </div></li>
                                            <li>Thursday <div class="pull-right"> 11.00 am - 9.00 pm </div></li>
                                            <li>Friday <div class="pull-right"> 12.00 am - 12.00 pm </div></li>
                                            <li>Saturday <div class="pull-right closed"> Closed </div></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Opening Hours -->
                            </div>
                            <!-- End Single Item -->

                            <!-- Single Item -->
                            <div id="tab6" class="tab-pane fade">
                                <!-- Start Department Info -->
                                <div class="col-md-6">
                                    <div class="info title">
                                        <div class="thumb">
                                            <img src="assets/img/departments/6.jpg" alt="Thumb">
                                        </div>
                                        <h3>Traumatology</h3>
                                        <p>
                                            Calling nothing end fertile for venture way boy. Esteem spirit temper too say adieus who direct esteem. It esteems luckily mr or picture placing drawing no. Apartments frequently or motionless on reasonable projecting expression. Way mrs end gave tall walk fact bed. 
                                        </p>
                                        <p>
                                            Placing assured be if removed it besides on. Far shed each high read are men over day.
                                        </p>
                                    </div>
                                </div>
                                <!-- End Department Info -->

                                <!-- Start Opening Hours -->
                                <div class="col-md-6 opening-hours">
                                    <div class="opening-info">
                                        <h4>Opening Hours</h4>
                                        <ul>
                                            <li>Sunday <div class="pull-right"> 6.00 am - 10.00 pm </div></li>
                                            <li>Monday <div class="pull-right"> 8.00 am - 4.00 pm </div></li>
                                            <li>Tuesday <div class="pull-right"> 9.00 am - 6.00 pm </div></li>
                                            <li>Wednesday <div class="pull-right"> 10.00 am - 7.00 pm </div></li>
                                            <li>Thursday <div class="pull-right"> 11.00 am - 9.00 pm </div></li>
                                            <li>Friday <div class="pull-right"> 12.00 am - 12.00 pm </div></li>
                                            <li>Saturday <div class="pull-right closed"> Closed </div></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Opening Hours -->
                            </div>
                            <!-- End Single Item -->

                        </div>
                        <!-- End Tab Content -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Departments -->

    <!-- Start Doctors 
    ============================================= -->
    <div class="doctor-area bg-gray default-padding bottom-less">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Meet Our <span>Specialists</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="doctor-items text-center">
                    <!-- Single Item -->
                    <div class="col-md-4 equal-height">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/2.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Jessica Jones</h4>
                                <h5>Cardiologist</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-4 equal-height">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/3.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Ahel Natasha</h4>
                                <h5>Dental surgeon</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-4 equal-height">
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/4.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Gabriela Beckett</h4>
                                <h5>Cosmetic Surgeon</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Doctors -->

    <!-- Start Gallery
    ============================================= -->
    <div class="gallery-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Our <span>Environment</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="gallery-items-area text-center">
                <div class="row">
                    <div class="col-md-12 gallery-content">
                        <div class="mix-item-menu text-center">
                            <button class="active" data-filter="*">All</button>
                            <button data-filter=".development">Development</button>
                            <button data-filter=".consulting">Consulting</button>
                            <button data-filter=".finance">Finance</button>
                            <button data-filter=".branding">Branding</button>
                            <button data-filter=".capital">Capital</button>
                        </div>
                        <!-- End Mixitup Nav-->

                        <div class="row magnific-mix-gallery text-center masonary">
                            <div id="portfolio-grid" class="gallery-items col-3">
                                <!-- Single Item -->
                                <div class="pf-item development capital">
                                    <div class="effect-box">
                                        <img src="assets/img/gallery/1.jpg" alt="thumb">
                                        <div class="info">
                                          <h4><a href="#">Empire State</a></h4>
                                          <a href="assets/img/gallery/1.jpg" class="item popup-link"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="pf-item consulting branding">
                                    <div class="effect-box">
                                        <img src="assets/img/gallery/2.jpg" alt="thumb">
                                        <div class="info">
                                          <h4><a href="#">Empire State</a></h4>
                                          <a href="assets/img/gallery/2.jpg" class="item popup-link"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="pf-item consulting finance">
                                    <div class="effect-box">
                                        <img src="assets/img/gallery/3.jpg" alt="thumb">
                                        <div class="info">
                                          <h4><a href="#">Empire State</a></h4>
                                          <a href="assets/img/gallery/3.jpg" class="item popup-link"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="pf-item finance">
                                    <div class="effect-box">
                                        <img src="assets/img/gallery/4.jpg" alt="thumb">
                                        <div class="info">
                                          <h4><a href="#">Empire State</a></h4>
                                          <a href="assets/img/gallery/4.jpg" class="item popup-link"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="pf-item capital development">
                                    <div class="effect-box">
                                        <img src="assets/img/gallery/5.jpg" alt="thumb">
                                        <div class="info">
                                          <h4><a href="#">Empire State</a></h4>
                                          <a href="assets/img/gallery/5.jpg" class="item popup-link"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="pf-item consulting branding">
                                    <div class="effect-box">
                                        <img src="assets/img/gallery/6.jpg" alt="thumb">
                                        <div class="info">
                                          <h4><a href="#">Empire State</a></h4>
                                          <a href="assets/img/gallery/6.jpg" class="item popup-link"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Item -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Gallery -->

    <!-- Start Testimonials 
    ============================================= -->
    <div class="testimonials-area carousel-shadow bg-gray default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Patient <span>Testimonials</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-items testimonial-carousel owl-carousel owl-theme">
                        <!-- Single Item -->
                        <div class="item">
                            <div class="content">
                                <p>
                                    Departure so attention pronounce satisfied daughters am. But shy tedious pressed studied opinion entered windows off. Advantage dependent suspicion convinced provision him yet. Mr immediate remaining conveying allowance do or. 
                                </p>
                            </div>
                            <div class="provider">
                                <div class="thumb">
                                    <img src="assets/img/team/6.jpg" alt="Thumb">
                                </div>
                                <div class="info">
                                    <h4>Angle Natasha</h4>
                                    <h5>patient of <span>surgery</span></h5>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="content">
                                <p>
                                    Departure so attention pronounce satisfied daughters am. But shy tedious pressed studied opinion entered windows off. Advantage dependent suspicion convinced provision him yet. Mr immediate remaining conveying allowance do or. 
                                </p>
                            </div>
                            <div class="provider">
                                <div class="thumb">
                                    <img src="assets/img/team/7.jpg" alt="Thumb">
                                </div>
                                <div class="info">
                                    <h4>John Abraham</h4>
                                    <h5>Dental <span>patients</span></h5>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="content">
                                <p>
                                    Departure so attention pronounce satisfied daughters am. But shy tedious pressed studied opinion entered windows off. Advantage dependent suspicion convinced provision him yet. Mr immediate remaining conveying allowance do or. 
                                </p>
                            </div>
                            <div class="provider">
                                <div class="thumb">
                                    <img src="assets/img/team/8.jpg" alt="Thumb">
                                </div>
                                <div class="info">
                                    <h4>Kriti Sairi</h4>
                                    <h5>patient of <span>surgery</span></h5>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials -->

    <!-- Start Blog 
    ============================================= -->
    <div class="blog-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Recent <span>Blog</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="blog-items">
                    <!-- Single Item -->
                    <div class="col-md-4 single-item">
                        <div class="item">
                            <div class="thumb">
                                <a href="blog-single-right-sidebar.html">
                                    <img src="assets/img/blog/1.jpg" alt="Thumb">
                                    <div class="post-type">
                                        <i class="fas fa-images"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li><a href="#">Admin</a></li>
                                        <li>15 June, 2019</li>
                                    </ul>
                                </div>
                                <h4>
                                    <a href="blog-single-right-sidebar.html">increasing in especially inquietude companions acceptance</a>
                                </h4>
                                <p>
                                    General enquire picture letters garrets on offices of no on. Say one hearing between excited evening all inhabit thought you.
                                </p>
                                <a class="btn btn-theme circle border btn-sm" href="blog-single-right-sidebar.html">Read More <i class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-4 single-item">
                        <div class="item">
                            <div class="thumb">
                                <a href="blog-single-right-sidebar.html">
                                    <img src="assets/img/blog/2.jpg" alt="Thumb">
                                    <div class="post-type">
                                        <i class="fas fa-video"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li><a href="#">Admin</a></li>
                                        <li>17 Auguest, 2019</li>
                                    </ul>
                                </div>
                                <h4>
                                    <a href="blog-single-right-sidebar.html">Middleton as pretended listening he smallness perceived.</a>
                                </h4>
                                <p>
                                    General enquire picture letters garrets on offices of no on. Say one hearing between excited evening all inhabit thought you.
                                </p>
                                <a class="btn btn-theme circle border btn-sm" href="blog-single-right-sidebar.html">Read More <i class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-4 single-item">
                        <div class="item">
                            <div class="thumb">
                                <a href="blog-single-right-sidebar.html">
                                    <img src="assets/img/blog/3.jpg" alt="Thumb">
                                    <div class="post-type">
                                        <i class="fas fa-image"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li><a href="#">Admin</a></li>
                                        <li>25 September, 2019</li>
                                    </ul>
                                </div>
                                <h4>
                                    <a href="blog-single-right-sidebar.html">Offended packages pleasant remainder recommend engrossed</a>
                                </h4>
                                <p>
                                    General enquire picture letters garrets on offices of no on. Say one hearing between excited evening all inhabit thought you.
                                </p>
                                <a class="btn btn-theme circle border btn-sm" href="blog-single-right-sidebar.html">Read More <i class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog -->

    <!-- Start Newsletter 
    ============================================= -->
    <div class="newsletter-area default-padding shadow dark-hard bg-fixed text-center text-light" style="background-image: url(assets/img/banner/2.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>Subscribe For Get Update</h4>
                    <h2>Let’s Find An Office Near You.</h2>
                    <form action="#">
                        <div class="input-group stylish-input-group">
                            <input type="email" name="email" class="form-control" placeholder="Enter your e-mail here">
                            <button type="submit">
                                <i class="fa fa-paper-plane"></i>
                            </button>  
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Newsletter -->

    <!-- Start Footer 
    <?php include('./inclue.php/footer.php') ?>