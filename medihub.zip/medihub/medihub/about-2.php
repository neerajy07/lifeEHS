<?php include ('./inclue.php/header.php') ?>

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area shadow dark bg-fixed text-light"
        style="background-image: url(assets/img/banner/7.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1>About Us</h1>
                </div>
                <div class="col-md-6 text-right">
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">About</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Features
    ============================================= -->
    <div class="chose-us-area">
        <div class="container-full">
            <div class="row">
                <div class="col-md-6 thumb bg-cover" style="background-image: url(assets/img/banner/6.jpg);"></div>
                <div class="col-md-6 info">
                    <div class="heading">
                        <h2>About Us </h2>
                        <p>
                            Welcome to LIFE EHS, your trusted partner in medical services across India. With over 30
                            years of dedicated experience in the telecom industry, we specialize in providing essential
                            medical services tailored for various sectors including telecom, corporate offices, and
                            more.
                            Our services include comprehensive medical checkups, specialized vertigo assessments, and
                            rigorous first aid and Défense driving training for professionals in height works, rigging,
                            engineering, and telecommunications. We also excel in safety products, fire training, and
                            audit services, ensuring compliance and peace of mind for our clients.
                            At LIFE EHS, we are committed to delivering high-quality medical solutions and safety
                            training that meet industry standards and exceed expectations. Partner with us for a safer,
                            healthier tomorrow.

                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Features -->
    <!-- gole -->
    <div class="chose-us-area">
        <div class="container-full">
            <div class="row">

                <div class="col-md-6 info">
                    <div class="heading">
                        <h2>Our Goal </h2>
                        <p>
                            <strong>Enhancing Health and Safety for Telecom Industry Workers,</strong> our mission is to
                            provide essential medical services tailored specifically for height workers in the telecom
                            industry. We understand the critical nature of their work and are dedicated to ensuring
                            their health and safety through specialized medical checkups, including comprehensive
                            vertigo tests and other medical testing plays a crucial role in identifying and managing
                            vestibular disorders that can significantly impact workers' safety at heights. By detecting
                            balance and orientation issues early on, we help mitigate risks of accidents and injuries,
                            ensuring that height workers can perform their duties safely and effectively.
                            Join us at LIFE EHS as we prioritize the well-being of telecom industry height workers
                            through expert medical care and proactive safety measures.


                        </p>
                    </div>

                </div>
                <div class="col-md-6 thumb bg-cover" style="background-image: url(assets/img/banner/11.jpg);"></div>
            </div>
        </div>
    </div>
    <!-- goleend -->
    <!-- Start Services
    ============================================= -->
    <div class="solid-services-area default-padding bottom-less">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Our <span>Services</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it
                            examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="services-items">
                    <!-- Single Item -->
                    <div class="col-md-4 col-sm-6 equal-height">
                        <div class="item">
                            <i class="flaticon-tooth"></i>
                            <h4>Medical Checkup </h4>
                            <ul>
                                <li>Height / weight check</li>
                                <li>Blood pressure check</li>
                                <li>Cholesterol level check</li>
                                <li>Blood sugar test</li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-4 col-sm-6 equal-height">
                        <div class="item">
                            <i class="flaticon-department-1"></i>
                            <h4>Vertigo Checkup</h4>
                            <ul>
                                <li>Utility Columns</li>
                                <li>Surgical and Exam Lights</li>
                                <li>Stretchers and Stretcher Accessories</li>
                                <li>Cushions and Mattresses</li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-4 col-sm-6 equal-height">
                        <div class="item">
                            <i class="flaticon-pharmacy"></i>
                            <h4>First Aid Training </h4>
                            <ul>
                                <li>Drug Side Effects</li>
                                <li>Treatment Options</li>
                                <li>International Drug Database</li>
                                <li>Breastfeeding Warnings</li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Item -->

                </div>
            </div>
        </div>
    </div>
    <!-- End Services -->

    <!-- Start Doctors 
    ============================================= -->
    <div class="doctor-area bg-gray carousel-shadow default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="site-heading text-center">
                        <h2>Meet Our <span>Specialists</span></h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it
                            examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="doctor-items doctor-carousel owl-carousel owl-theme text-center">
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/2.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Jessica Jones</h4>
                                <h5>Cardiologist</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/3.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Ahel Natasha</h4>
                                <h5>Dental surgeon</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/4.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Gabriela Beckett</h4>
                                <h5>Cosmetic Surgeon</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/5.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Ahel Natasha</h4>
                                <h5>Dental surgeon</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <img src="assets/img/doctors/6.jpg" alt="Thumb">
                                <div class="overlay">
                                    <a href="#"><i class="fas fa-plus"></i></a>
                                </div>
                                <div class="social">
                                    <ul>
                                        <li class="facebook">
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li class="twitter">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram">
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="linkedin">
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <h4>Gabriela Beckett</h4>
                                <h5>Cosmetic Surgeon</h5>
                                <div class="appoinment-btn">
                                    <a href="#">Make appoinment</a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Doctors -->

    <!-- Start Fun Factor
    ============================================= -->
    <div class="fun-fact-area default-padding shadow light text-center bg-fixed text-light"
        style="background-image: url(assets/img/banner/5.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 item">
                    <div class="fun-fact">
                        <i class="flaticon-recovered"></i>
                        <div class="timer" data-to="230" data-speed="5000"></div>
                        <span class="medium">Satisfied Patients</span>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 item">
                    <div class="fun-fact">
                        <i class="flaticon-doctor"></i>
                        <div class="timer" data-to="89" data-speed="5000"></div>
                        <span class="medium">Regular Doctors</span>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 item">
                    <div class="fun-fact">
                        <i class="flaticon-department"></i>
                        <div class="timer" data-to="50" data-speed="5000"></div>
                        <span class="medium">Departments</span>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 item">
                    <div class="fun-fact">
                        <i class="flaticon-nurse"></i>
                        <div class="timer" data-to="2348" data-speed="5000"></div>
                        <span class="medium">Servant</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Fun Factor -->

    <!-- Start Footer 
    ============================================= -->
    <?php include ('./inclue.php/footer.php') ?>
    <!-- End Footer -->